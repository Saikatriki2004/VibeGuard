import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { RefreshCw, Download, CheckCircle, Clock, AlertTriangle } from 'lucide-react';

const Updates: React.FC = () => {
  const { highContrast } = useTheme();
  const [selectedTab, setSelectedTab] = useState('available');
  
  // Sample updates data
  const availableUpdates = [
    {
      id: 'FW2301',
      version: 'v2.4.0',
      releaseDate: '2025-06-08',
      type: 'Security',
      component: 'Gateway Firmware',
      description: 'Critical security patch for CVE-2025-1234. Fixes remote code execution vulnerability.',
      devices: ['GW001', 'GW002', 'GW003', 'GW004'],
      size: '3.2 MB',
      priority: 'critical'
    },
    {
      id: 'FW2302',
      version: 'v1.8.5',
      releaseDate: '2025-06-07',
      type: 'Feature',
      component: 'Sensor Firmware',
      description: 'Adds support for enhanced power management and improves battery life by up to 20%.',
      devices: ['SN101', 'SN102', 'SN103', 'SN104'],
      size: '1.8 MB',
      priority: 'medium'
    },
    {
      id: 'FW2303',
      version: 'v3.1.0',
      releaseDate: '2025-06-05',
      type: 'Improvement',
      component: 'Controller Firmware',
      description: 'Performance optimization for HVAC controllers. Reduces response time by 15%.',
      devices: ['CT201', 'CT202'],
      size: '2.5 MB',
      priority: 'low'
    }
  ];
  
  const updateHistory = [
    {
      id: 'FW2204',
      version: 'v2.3.1',
      component: 'Gateway Firmware',
      installedDate: '2025-05-20',
      status: 'success',
      devices: ['GW001', 'GW002', 'GW003', 'GW004'],
    },
    {
      id: 'FW2205',
      version: 'v1.8.0',
      component: 'Sensor Firmware',
      installedDate: '2025-05-15',
      status: 'success',
      devices: ['SN101', 'SN102', 'SN104'],
    },
    {
      id: 'FW2206',
      version: 'v1.8.0',
      component: 'Sensor Firmware',
      installedDate: '2025-05-14',
      status: 'failed',
      devices: ['SN103'],
      errorMessage: 'Connection timeout during installation'
    },
    {
      id: 'FW2207',
      version: 'v3.0.2',
      component: 'Controller Firmware',
      installedDate: '2025-05-10',
      status: 'success',
      devices: ['CT201', 'CT202'],
    }
  ];
  
  const scheduledUpdates = [
    {
      id: 'SCH001',
      updateId: 'FW2301',
      version: 'v2.4.0',
      component: 'Gateway Firmware',
      scheduledDate: '2025-06-12 02:00 AM',
      devices: ['GW001', 'GW002'],
      status: 'scheduled'
    },
    {
      id: 'SCH002',
      updateId: 'FW2302',
      version: 'v1.8.5',
      component: 'Sensor Firmware',
      scheduledDate: '2025-06-13 03:00 AM',
      devices: ['SN101', 'SN102'],
      status: 'scheduled'
    }
  ];
  
  const getPriorityClass = (priority: string) => {
    if (highContrast) {
      switch (priority) {
        case 'critical': return 'text-red-500';
        case 'high': return 'text-orange-500';
        case 'medium': return 'text-yellow-500';
        case 'low': default: return 'text-blue-500';
      }
    }
    
    switch (priority) {
      case 'critical': return 'text-neon-red';
      case 'high': return 'text-terminal-amber';
      case 'medium': return 'text-terminal-amber';
      case 'low': default: return 'text-neon-cyan';
    }
  };
  
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle size={16} className={highContrast ? 'text-green-500' : 'text-terminal-green'} />;
      case 'failed':
        return <AlertTriangle size={16} className={highContrast ? 'text-red-500' : 'text-neon-red'} />;
      case 'scheduled':
        return <Clock size={16} className={highContrast ? 'text-blue-500' : 'text-neon-cyan'} />;
      default:
        return null;
    }
  };
  
  const renderTabContent = () => {
    switch (selectedTab) {
      case 'available':
        return (
          <div className="space-y-4">
            {availableUpdates.map((update) => (
              <div 
                key={update.id}
                className={`p-4 border rounded-lg ${
                  highContrast 
                    ? 'bg-gray-900 border-gray-700' 
                    : 'bg-navy-800 border-navy-700'
                }`}
              >
                <div className="flex flex-col md:flex-row justify-between gap-3 mb-3">
                  <div>
                    <h3 className="font-bold font-mono text-lg flex items-center gap-2">
                      {update.component} 
                      <span className={getPriorityClass(update.priority)}>
                        {update.version}
                      </span>
                    </h3>
                    <div className="text-sm text-gray-500 font-mono">
                      ID: {update.id} • Released: {update.releaseDate} • Type: {update.type}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button className={`px-3 py-1 rounded flex items-center gap-1 ${
                      highContrast 
                        ? 'bg-blue-600 hover:bg-blue-700' 
                        : 'bg-navy-700 border border-neon-cyan text-neon-cyan hover:bg-navy-600'
                      }`}
                    >
                      <Download size={14} />
                      <span>Deploy Now</span>
                    </button>
                    
                    <button className={`px-3 py-1 rounded ${
                      highContrast 
                        ? 'bg-gray-800 hover:bg-gray-700 border-gray-700' 
                        : 'bg-navy-700 hover:bg-navy-600 border-navy-600'
                      } border`}
                    >
                      Schedule
                    </button>
                  </div>
                </div>
                
                <p className="text-sm mb-4 font-mono">
                  {update.description}
                </p>
                
                <div className="flex flex-wrap gap-3 text-sm">
                  <div>
                    <span className="text-gray-500 mr-1 font-mono">Size:</span>
                    <span className="font-mono">{update.size}</span>
                  </div>
                  
                  <div>
                    <span className="text-gray-500 mr-1 font-mono">Affected Devices:</span>
                    <span className="font-mono">{update.devices.length}</span>
                  </div>
                  
                  <div>
                    <span className="text-gray-500 mr-1 font-mono">Priority:</span>
                    <span className={`font-mono uppercase ${getPriorityClass(update.priority)}`}>
                      {update.priority}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        );
      
      case 'scheduled':
        return (
          <div className="space-y-4">
            {scheduledUpdates.map((update) => (
              <div 
                key={update.id}
                className={`p-4 border rounded-lg ${
                  highContrast 
                    ? 'bg-gray-900 border-gray-700' 
                    : 'bg-navy-800 border-navy-700'
                }`}
              >
                <div className="flex flex-col md:flex-row justify-between gap-3 mb-3">
                  <div>
                    <h3 className="font-bold font-mono text-lg flex items-center gap-2">
                      {update.component} 
                      <span className="text-neon-cyan">
                        {update.version}
                      </span>
                    </h3>
                    <div className="text-sm text-gray-500 font-mono flex items-center gap-1">
                      <Clock size={14} />
                      Scheduled for: {update.scheduledDate}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button className={`px-3 py-1 rounded ${
                      highContrast 
                        ? 'bg-red-600 hover:bg-red-700' 
                        : 'bg-navy-700 border border-neon-red text-neon-red hover:bg-navy-600'
                      }`}
                    >
                      Cancel
                    </button>
                    
                    <button className={`px-3 py-1 rounded ${
                      highContrast 
                        ? 'bg-gray-800 hover:bg-gray-700 border-gray-700' 
                        : 'bg-navy-700 hover:bg-navy-600 border-navy-600'
                      } border`}
                    >
                      Reschedule
                    </button>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-3 text-sm">
                  <div>
                    <span className="text-gray-500 mr-1 font-mono">Update ID:</span>
                    <span className="font-mono">{update.updateId}</span>
                  </div>
                  
                  <div>
                    <span className="text-gray-500 mr-1 font-mono">Target Devices:</span>
                    <span className="font-mono">{update.devices.join(', ')}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        );
      
      case 'history':
        return (
          <div className={`${
            highContrast ? 'bg-gray-900 border-gray-700' : 'bg-navy-800 border-navy-700'
          } border rounded-lg overflow-hidden`}>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className={`${
                    highContrast ? 'bg-gray-800' : 'bg-navy-700'
                  } border-b ${
                    highContrast ? 'border-gray-700' : 'border-navy-600'
                  }`}>
                    <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">ID</th>
                    <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">Component</th>
                    <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">Version</th>
                    <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">Date</th>
                    <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">Devices</th>
                    <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {updateHistory.map((update, index) => (
                    <tr key={update.id} className={`${
                      index % 2 === 0 
                        ? (highContrast ? 'bg-gray-900' : 'bg-navy-800') 
                        : (highContrast ? 'bg-gray-800' : 'bg-navy-700')
                    } hover:${
                      highContrast ? 'bg-gray-700' : 'bg-navy-600'
                    }`}>
                      <td className="px-6 py-4 text-sm font-mono">{update.id}</td>
                      <td className="px-6 py-4 text-sm font-mono">{update.component}</td>
                      <td className="px-6 py-4 text-sm font-mono">{update.version}</td>
                      <td className="px-6 py-4 text-sm font-mono">{update.installedDate}</td>
                      <td className="px-6 py-4 text-sm font-mono">{update.devices.length} devices</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          {getStatusIcon(update.status)}
                          <span className={`ml-1 text-sm font-mono ${
                            update.status === 'success' 
                              ? (highContrast ? 'text-green-500' : 'text-terminal-green')
                              : (highContrast ? 'text-red-500' : 'text-neon-red')
                          }`}>
                            {update.status.toUpperCase()}
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };
  
  return (
    <div className="space-y-6">
      <header>
        <h1 className={`text-2xl font-pixel ${highContrast ? 'text-white' : 'text-neon-purple glow-purple'} mb-2`}>
          FIRMWARE UPDATES
        </h1>
        <p className="text-gray-400 font-mono text-sm">
          Manage and deploy secure over-the-air updates
        </p>
      </header>
      
      <div className="flex border-b border-gray-700 mb-4">
        <button
          className={`py-2 px-4 font-mono text-sm ${
            selectedTab === 'available' 
              ? (highContrast 
                ? 'border-b-2 border-blue-500 text-blue-500' 
                : 'border-b-2 border-neon-cyan text-neon-cyan')
              : 'text-gray-400 hover:text-gray-300'
          }`}
          onClick={() => setSelectedTab('available')}
        >
          Available ({availableUpdates.length})
        </button>
        
        <button
          className={`py-2 px-4 font-mono text-sm ${
            selectedTab === 'scheduled' 
              ? (highContrast 
                ? 'border-b-2 border-blue-500 text-blue-500' 
                : 'border-b-2 border-neon-cyan text-neon-cyan')
              : 'text-gray-400 hover:text-gray-300'
          }`}
          onClick={() => setSelectedTab('scheduled')}
        >
          Scheduled ({scheduledUpdates.length})
        </button>
        
        <button
          className={`py-2 px-4 font-mono text-sm ${
            selectedTab === 'history' 
              ? (highContrast 
                ? 'border-b-2 border-blue-500 text-blue-500' 
                : 'border-b-2 border-neon-cyan text-neon-cyan')
              : 'text-gray-400 hover:text-gray-300'
          }`}
          onClick={() => setSelectedTab('history')}
        >
          History
        </button>
      </div>
      
      {renderTabContent()}
    </div>
  );
};

export default Updates;