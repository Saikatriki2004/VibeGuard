import React, { useState } from 'react';
import { KeyRound, User, Shield } from 'lucide-react';

interface LoginProps {
  onLogin: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('********');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      onLogin();
    }, 1500);
  };

  return (
    <div className="min-h-screen grid place-items-center crt scanline bg-navy-900 grid-bg p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 flex justify-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 relative">
              <div className="absolute inset-0 bg-navy-800 border-2 border-neon-pink rounded pixel-corners"></div>
              <Shield size={24} className="absolute inset-0 m-auto text-neon-pink" />
            </div>
            <h1 className="font-pixel text-2xl text-neon-pink glow-pink">VIBE<span className="text-neon-cyan glow-cyan">GUARD</span></h1>
          </div>
        </div>
        
        <div className="bg-navy-800 border border-navy-700 rounded pixel-corners p-6 animate-flicker">
          <div className="mb-6">
            <h2 className="font-pixel text-neon-cyan text-center text-lg mb-1 glow-cyan">SECURE LOGIN</h2>
            <p className="text-gray-400 text-center text-sm font-mono">Enter credentials to access system</p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="block text-sm font-mono text-gray-300">USERNAME</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User size={16} className="text-gray-500" />
                </div>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full py-2 pl-10 pr-3 bg-navy-900 border border-navy-600 rounded text-gray-200 font-mono focus:outline-none focus:border-neon-cyan focus:border-glow-cyan transition-colors"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="block text-sm font-mono text-gray-300">PASSWORD</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <KeyRound size={16} className="text-gray-500" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full py-2 pl-10 pr-3 bg-navy-900 border border-navy-600 rounded text-gray-200 font-mono focus:outline-none focus:border-neon-cyan focus:border-glow-cyan transition-colors"
                />
              </div>
            </div>
            
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2 px-4 bg-navy-700 hover:bg-navy-600 border border-neon-cyan text-neon-cyan font-pixel rounded transition-colors focus:outline-none focus:border-glow-cyan disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="inline-block w-4 h-4 border-2 border-transparent border-t-current rounded-full animate-spin"></span>
                  AUTHENTICATING...
                </span>
              ) : 'LOGIN'}
            </button>
          </form>
          
          <div className="mt-6 pt-4 border-t border-navy-700">
            <p className="text-xs text-gray-500 font-mono">
              SECURE ACCESS POINT • TLS 1.3 ENCRYPTED • RSA-4096
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;