import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { Shield, User, Lock, Bell, Zap, Download, Moon, Settings as SettingsIcon, Sliders } from 'lucide-react';

const Settings: React.FC = () => {
  const { highContrast, toggleHighContrast } = useTheme();
  const [activeTab, setActiveTab] = useState('general');
  
  const SettingsTab = ({ id, icon: Icon, label }: { id: string, icon: React.ElementType, label: string }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`flex items-center gap-3 px-4 py-3 w-full text-left ${
        activeTab === id 
          ? (highContrast 
            ? 'bg-gray-800 border-l-4 border-blue-500' 
            : 'bg-navy-700 border-l-4 border-neon-cyan')
          : (highContrast 
            ? 'hover:bg-gray-800' 
            : 'hover:bg-navy-700')
      }`}
    >
      <Icon size={18} className={activeTab === id ? (highContrast ? 'text-blue-500' : 'text-neon-cyan') : ''} />
      <span className="font-mono text-sm">{label}</span>
    </button>
  );
  
  const ToggleSetting = ({ 
    label, 
    description, 
    isEnabled, 
    onChange 
  }: { 
    label: string, 
    description: string, 
    isEnabled: boolean, 
    onChange: () => void 
  }) => (
    <div className="flex items-center justify-between py-3 border-b border-gray-700">
      <div>
        <h3 className="font-mono text-sm font-bold">{label}</h3>
        <p className="text-xs text-gray-500 font-mono mt-1">{description}</p>
      </div>
      <div 
        onClick={onChange}
        className={`w-12 h-6 rounded-full flex items-center p-1 cursor-pointer transition-colors ${
          isEnabled 
            ? (highContrast ? 'bg-blue-600' : 'bg-neon-cyan') 
            : (highContrast ? 'bg-gray-700' : 'bg-navy-700')
        }`}
      >
        <div 
          className={`w-4 h-4 rounded-full bg-white transform transition-transform ${
            isEnabled ? 'translate-x-6' : ''
          }`}
        />
      </div>
    </div>
  );
  
  const renderTabContent = () => {
    switch (activeTab) {
      case 'general':
        return (
          <div>
            <h2 className={`text-xl font-pixel mb-6 ${highContrast ? 'text-white' : 'text-neon-purple'}`}>
              General Settings
            </h2>
            
            <div className="space-y-6">
              <ToggleSetting
                label="High Contrast Mode"
                description="Enable high contrast theme for better accessibility"
                isEnabled={highContrast}
                onChange={toggleHighContrast}
              />
              
              <ToggleSetting
                label="Auto-Refresh Dashboard"
                description="Automatically refresh dashboard data every 30 seconds"
                isEnabled={true}
                onChange={() => {}}
              />
              
              <ToggleSetting
                label="Show ASCII Art"
                description="Display ASCII art representations of devices in network view"
                isEnabled={true}
                onChange={() => {}}
              />
              
              <ToggleSetting
                label="Enable CRT Effects"
                description="Display retro CRT screen effects throughout the interface"
                isEnabled={true}
                onChange={() => {}}
              />
              
              <div className="py-3 border-b border-gray-700">
                <h3 className="font-mono text-sm font-bold">Time Zone</h3>
                <p className="text-xs text-gray-500 font-mono mt-1 mb-2">
                  Select your local time zone for accurate timing
                </p>
                <select className={`w-full p-2 rounded ${
                  highContrast 
                    ? 'bg-gray-800 border-gray-700' 
                    : 'bg-navy-700 border-navy-600'
                  } border`}
                >
                  <option>UTC (Coordinated Universal Time)</option>
                  <option>EST (Eastern Standard Time)</option>
                  <option>CST (Central Standard Time)</option>
                  <option>PST (Pacific Standard Time)</option>
                </select>
              </div>
            </div>
          </div>
        );
      
      case 'security':
        return (
          <div>
            <h2 className={`text-xl font-pixel mb-6 ${highContrast ? 'text-white' : 'text-neon-purple'}`}>
              Security Settings
            </h2>
            
            <div className="space-y-6">
              <ToggleSetting
                label="Enforce MFA"
                description="Require multi-factor authentication for all user accounts"
                isEnabled={true}
                onChange={() => {}}
              />
              
              <ToggleSetting
                label="Auto-Lockout"
                description="Automatically lock user accounts after 5 failed login attempts"
                isEnabled={true}
                onChange={() => {}}
              />
              
              <ToggleSetting
                label="Enhanced Logging"
                description="Enable detailed security event logging for all system actions"
                isEnabled={true}
                onChange={() => {}}
              />
              
              <div className="py-3 border-b border-gray-700">
                <h3 className="font-mono text-sm font-bold">Session Timeout</h3>
                <p className="text-xs text-gray-500 font-mono mt-1 mb-2">
                  Automatically log out inactive users after the specified time
                </p>
                <select className={`w-full p-2 rounded ${
                  highContrast 
                    ? 'bg-gray-800 border-gray-700' 
                    : 'bg-navy-700 border-navy-600'
                  } border`}
                >
                  <option>15 minutes</option>
                  <option>30 minutes</option>
                  <option>1 hour</option>
                  <option>4 hours</option>
                </select>
              </div>
              
              <div className="py-3 border-b border-gray-700">
                <h3 className="font-mono text-sm font-bold">Certificate Management</h3>
                <p className="text-xs text-gray-500 font-mono mt-1 mb-2">
                  Manage cryptographic certificates for device authentication
                </p>
                <button className={`px-3 py-2 rounded ${
                  highContrast 
                    ? 'bg-blue-600 hover:bg-blue-700' 
                    : 'bg-navy-700 border border-neon-cyan text-neon-cyan hover:bg-navy-600'
                  }`}
                >
                  Manage Certificates
                </button>
              </div>
            </div>
          </div>
        );
      
      case 'notifications':
        return (
          <div>
            <h2 className={`text-xl font-pixel mb-6 ${highContrast ? 'text-white' : 'text-neon-purple'}`}>
              Notification Settings
            </h2>
            
            <div className="space-y-6">
              <ToggleSetting
                label="Email Alerts"
                description="Receive email notifications for critical security events"
                isEnabled={true}
                onChange={() => {}}
              />
              
              <ToggleSetting
                label="SMS Alerts"
                description="Receive text message alerts for critical security events"
                isEnabled={false}
                onChange={() => {}}
              />
              
              <ToggleSetting
                label="In-App Notifications"
                description="Show notifications in the dashboard interface"
                isEnabled={true}
                onChange={() => {}}
              />
              
              <ToggleSetting
                label="Update Notifications"
                description="Receive alerts when new firmware updates are available"
                isEnabled={true}
                onChange={() => {}}
              />
              
              <div className="py-3 border-b border-gray-700">
                <h3 className="font-mono text-sm font-bold">Notification Recipients</h3>
                <p className="text-xs text-gray-500 font-mono mt-1 mb-2">
                  Add email addresses for notification delivery
                </p>
                <div className="flex gap-2">
                  <input 
                    type="email" 
                    placeholder="Enter email address"
                    className={`flex-1 p-2 rounded ${
                      highContrast 
                        ? 'bg-gray-800 border-gray-700' 
                        : 'bg-navy-700 border-navy-600'
                    } border`}
                  />
                  <button className={`px-3 py-2 rounded ${
                    highContrast 
                      ? 'bg-blue-600 hover:bg-blue-700' 
                      : 'bg-navy-700 border border-neon-cyan text-neon-cyan hover:bg-navy-600'
                    }`}
                  >
                    Add
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      
      case 'system':
        return (
          <div>
            <h2 className={`text-xl font-pixel mb-6 ${highContrast ? 'text-white' : 'text-neon-purple'}`}>
              System Settings
            </h2>
            
            <div className="space-y-6">
              <div className="py-3 border-b border-gray-700">
                <h3 className="font-mono text-sm font-bold">System Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                  <div className="text-sm">
                    <span className="text-gray-500 block font-mono">Version:</span>
                    <span className="font-mono">VibeGuard v1.0.0</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-500 block font-mono">Database:</span>
                    <span className="font-mono">Secure SQL v4.2.1</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-500 block font-mono">Last Updated:</span>
                    <span className="font-mono">June 10, 2025 (14:30 UTC)</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-500 block font-mono">Node.js Version:</span>
                    <span className="font-mono">v20.5.1</span>
                  </div>
                </div>
              </div>
              
              <div className="py-3 border-b border-gray-700">
                <h3 className="font-mono text-sm font-bold">Maintenance</h3>
                <p className="text-xs text-gray-500 font-mono mt-1 mb-3">
                  System maintenance and diagnostic tools
                </p>
                <div className="flex flex-wrap gap-2">
                  <button className={`px-3 py-2 rounded ${
                    highContrast 
                      ? 'bg-blue-600 hover:bg-blue-700' 
                      : 'bg-navy-700 border border-neon-cyan text-neon-cyan hover:bg-navy-600'
                    }`}
                  >
                    Run Diagnostics
                  </button>
                  <button className={`px-3 py-2 rounded ${
                    highContrast 
                      ? 'bg-gray-700 hover:bg-gray-600' 
                      : 'bg-navy-700 border border-neon-purple text-neon-purple hover:bg-navy-600'
                    }`}
                  >
                    Export Logs
                  </button>
                  <button className={`px-3 py-2 rounded ${
                    highContrast 
                      ? 'bg-red-600 hover:bg-red-700' 
                      : 'bg-navy-700 border border-neon-red text-neon-red hover:bg-navy-600'
                    }`}
                  >
                    Reset System
                  </button>
                </div>
              </div>
              
              <div className="py-3 border-b border-gray-700">
                <h3 className="font-mono text-sm font-bold">Backup & Restore</h3>
                <p className="text-xs text-gray-500 font-mono mt-1 mb-3">
                  Create and manage system backups
                </p>
                <div className="flex flex-wrap gap-2">
                  <button className={`px-3 py-2 rounded ${
                    highContrast 
                      ? 'bg-blue-600 hover:bg-blue-700' 
                      : 'bg-navy-700 border border-neon-cyan text-neon-cyan hover:bg-navy-600'
                    }`}
                  >
                    Create Backup
                  </button>
                  <button className={`px-3 py-2 rounded ${
                    highContrast 
                      ? 'bg-gray-700 hover:bg-gray-600' 
                      : 'bg-navy-700 border border-gray-600 text-gray-400 hover:bg-navy-600'
                    }`}
                  >
                    Restore from Backup
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };
  
  return (
    <div className="space-y-6">
      <header>
        <h1 className={`text-2xl font-pixel ${highContrast ? 'text-white' : 'text-neon-purple glow-purple'} mb-2`}>
          SYSTEM SETTINGS
        </h1>
        <p className="text-gray-400 font-mono text-sm">
          Configure system preferences and security options
        </p>
      </header>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className={`${
          highContrast ? 'bg-gray-900 border-gray-700' : 'bg-navy-800 border-navy-700'
        } border rounded-lg overflow-hidden`}>
          <div className="flex flex-col">
            <SettingsTab id="general" icon={Sliders} label="General" />
            <SettingsTab id="security" icon={Shield} label="Security" />
            <SettingsTab id="notifications" icon={Bell} label="Notifications" />
            <SettingsTab id="users" icon={User} label="Users & Access" />
            <SettingsTab id="system" icon={SettingsIcon} label="System" />
          </div>
        </div>
        
        <div className={`md:col-span-3 ${
          highContrast ? 'bg-gray-900 border-gray-700' : 'bg-navy-800 border-navy-700'
        } border rounded-lg p-6`}>
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default Settings;