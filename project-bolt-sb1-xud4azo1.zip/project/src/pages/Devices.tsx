import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { HardDrive, Search, Plus, ChevronDown, Filter } from 'lucide-react';

const Devices: React.FC = () => {
  const { highContrast } = useTheme();
  
  // Sample devices data
  const devices = [
    { id: 'GW001', name: 'Main Gateway', type: 'gateway', status: 'online', location: 'Server Room', lastSeen: '2 minutes ago', firmware: 'v2.3.1' },
    { id: 'SN101', name: 'Temperature Sensor A', type: 'sensor', status: 'online', location: 'Floor 1', lastSeen: '5 minutes ago', firmware: 'v1.8.0' },
    { id: 'SN102', name: 'Humidity Sensor B', type: 'sensor', status: 'online', location: 'Floor 2', lastSeen: '8 minutes ago', firmware: 'v1.8.0' },
    { id: 'SN103', name: 'Motion Sensor C', type: 'sensor', status: 'warning', location: 'Floor 1', lastSeen: '12 minutes ago', firmware: 'v1.7.5' },
    { id: 'CT201', name: 'HVAC Controller', type: 'controller', status: 'online', location: 'Basement', lastSeen: '3 minutes ago', firmware: 'v3.0.2' },
    { id: 'SN104', name: 'Door Sensor D', type: 'sensor', status: 'offline', location: 'Floor 3', lastSeen: '2 days ago', firmware: 'v1.8.0' },
  ];
  
  const getStatusColor = (status: string) => {
    if (highContrast) {
      switch (status) {
        case 'online': return 'text-green-500';
        case 'warning': return 'text-yellow-500';
        case 'offline': return 'text-gray-500';
        default: return 'text-gray-500';
      }
    }
    
    switch (status) {
      case 'online': return 'text-terminal-green';
      case 'warning': return 'text-terminal-amber';
      case 'offline': return 'text-gray-500';
      default: return 'text-gray-500';
    }
  };
  
  return (
    <div className="space-y-6">
      <header>
        <h1 className={`text-2xl font-pixel ${highContrast ? 'text-white' : 'text-neon-purple glow-purple'} mb-2`}>
          DEVICE MANAGEMENT
        </h1>
        <p className="text-gray-400 font-mono text-sm">
          Enroll, monitor, and manage your devices
        </p>
      </header>
      
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className={`relative ${highContrast ? '' : 'border-glow-cyan'}`}>
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={16} className="text-gray-500" />
          </div>
          <input
            type="text"
            placeholder="Search devices..."
            className={`pl-10 pr-4 py-2 ${
              highContrast 
                ? 'bg-gray-900 border-gray-700 focus:border-blue-500' 
                : 'bg-navy-700 border-neon-cyan text-white focus:border-neon-pink'
            } border rounded w-full md:w-64 font-mono text-sm focus:outline-none`}
          />
        </div>
        
        <div className="flex items-center gap-3">
          <button className={`flex items-center gap-2 px-3 py-2 rounded ${
            highContrast 
              ? 'bg-gray-800 hover:bg-gray-700 border-gray-700' 
              : 'bg-navy-700 hover:bg-navy-600 border-navy-600'
            } border`}
          >
            <Filter size={16} />
            <span className="text-sm font-mono">Filter</span>
            <ChevronDown size={14} />
          </button>
          
          <button className={`flex items-center gap-2 px-3 py-2 rounded ${
            highContrast 
              ? 'bg-blue-600 hover:bg-blue-700' 
              : 'bg-neon-purple hover:bg-purple-700 border-glow-purple'
            } border border-neon-purple text-white`}
          >
            <Plus size={16} />
            <span className="text-sm font-mono">Enroll Device</span>
          </button>
        </div>
      </div>
      
      <div className={`${
        highContrast ? 'bg-gray-900 border-gray-700' : 'bg-navy-800 border-navy-700'
      } border rounded-lg overflow-hidden`}>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className={`${
                highContrast ? 'bg-gray-800' : 'bg-navy-700'
              } border-b ${
                highContrast ? 'border-gray-700' : 'border-navy-600'
              }`}>
                <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">ID</th>
                <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">Location</th>
                <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">Last Seen</th>
                <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">Firmware</th>
                <th className="px-6 py-3 text-left text-xs font-mono uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody>
              {devices.map((device, index) => (
                <tr key={device.id} className={`${
                  index % 2 === 0 
                    ? (highContrast ? 'bg-gray-900' : 'bg-navy-800') 
                    : (highContrast ? 'bg-gray-800' : 'bg-navy-700')
                } hover:${
                  highContrast ? 'bg-gray-700' : 'bg-navy-600'
                }`}>
                  <td className="px-6 py-4 text-sm font-mono">{device.id}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <HardDrive size={16} className="mr-2" />
                      <span className="text-sm font-mono">{device.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm font-mono capitalize">{device.type}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-mono ${getStatusColor(device.status)}`}>
                      <span className={`w-1.5 h-1.5 mr-1.5 rounded-full ${
                        device.status === 'online' 
                          ? (highContrast ? 'bg-green-500 animate-pulse' : 'bg-terminal-green animate-pulse') 
                          : device.status === 'warning' 
                            ? (highContrast ? 'bg-yellow-500' : 'bg-terminal-amber') 
                            : 'bg-gray-500'
                      }`}></span>
                      {device.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm font-mono">{device.location}</td>
                  <td className="px-6 py-4 text-sm font-mono">{device.lastSeen}</td>
                  <td className="px-6 py-4 text-sm font-mono">{device.firmware}</td>
                  <td className="px-6 py-4 text-sm font-mono">
                    <button className={`px-2 py-1 text-xs rounded ${
                      highContrast 
                        ? 'bg-gray-800 hover:bg-gray-700' 
                        : 'bg-navy-700 hover:bg-navy-600'
                    }`}>
                      Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Devices;