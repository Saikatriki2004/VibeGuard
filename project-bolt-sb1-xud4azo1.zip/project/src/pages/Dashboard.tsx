import React from 'react';
import { useTheme } from '../context/ThemeContext';
import StatusPanel from '../components/dashboard/StatusPanel';
import NetworkGraph from '../components/dashboard/NetworkGraph';
import DeviceStats from '../components/dashboard/DeviceStats';
import ThreatFeed from '../components/dashboard/ThreatFeed';
import TimelineSlider from '../components/dashboard/TimelineSlider';

const Dashboard: React.FC = () => {
  const { highContrast } = useTheme();
  
  return (
    <div className="space-y-6">
      <header>
        <h1 className={`text-2xl font-pixel ${highContrast ? 'text-white' : 'text-neon-purple glow-purple'} mb-2`}>
          SYSTEM DASHBOARD
        </h1>
        <p className="text-gray-400 font-mono text-sm">
          Security status and network overview
        </p>
      </header>
      
      <StatusPanel />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className={`${highContrast ? 'bg-gray-900 border-gray-700' : 'bg-navy-800 border-navy-700'} border rounded-lg p-4 h-[400px]`}>
            <h2 className={`text-lg font-pixel mb-4 ${highContrast ? 'text-white' : 'text-neon-cyan'}`}>
              NETWORK OVERVIEW
            </h2>
            <NetworkGraph />
          </div>
        </div>
        
        <div>
          <div className={`${highContrast ? 'bg-gray-900 border-gray-700' : 'bg-navy-800 border-navy-700'} border rounded-lg p-4 h-[400px] overflow-hidden`}>
            <h2 className={`text-lg font-pixel mb-4 ${highContrast ? 'text-white' : 'text-neon-pink'}`}>
              ACTIVE THREATS
            </h2>
            <ThreatFeed />
          </div>
        </div>
      </div>
      
      <div className={`${highContrast ? 'bg-gray-900 border-gray-700' : 'bg-navy-800 border-navy-700'} border rounded-lg p-4`}>
        <h2 className={`text-lg font-pixel mb-4 ${highContrast ? 'text-white' : 'text-neon-cyan'}`}>
          TIMELINE
        </h2>
        <TimelineSlider />
      </div>
      
      <DeviceStats />
    </div>
  );
};

export default Dashboard;