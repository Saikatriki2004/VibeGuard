import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { Shield, AlertTriangle, AlertCircle, Calendar, Search, Filter } from 'lucide-react';
import { useThreatStore } from '../store/threatStore';
import ThreatMonitor from '../components/threats/ThreatMonitor';

const Threats: React.FC = () => {
  const { highContrast } = useTheme();
  const [view, setView] = useState<'monitor' | 'history'>('monitor');
  const { threats } = useThreatStore();
  
  return (
    <div className="space-y-6">
      <header>
        <h1 className={`text-2xl font-pixel ${highContrast ? 'text-white' : 'text-neon-purple glow-purple'} mb-2`}>
          THREAT DETECTION
        </h1>
        <p className="text-gray-400 font-mono text-sm">
          Monitor and respond to security threats
        </p>
      </header>
      
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className={`relative ${highContrast ? '' : 'border-glow-cyan'}`}>
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={16} className="text-gray-500" />
            </div>
            <input
              type="text"
              placeholder="Search threats..."
              className={`pl-10 pr-4 py-2 ${
                highContrast 
                  ? 'bg-gray-900 border-gray-700 focus:border-blue-500' 
                  : 'bg-navy-700 border-neon-cyan text-white focus:border-neon-pink'
              } border rounded w-full md:w-64 font-mono text-sm focus:outline-none`}
            />
          </div>
          
          <button className={`flex items-center gap-2 px-3 py-2 rounded ${
            highContrast 
              ? 'bg-gray-800 hover:bg-gray-700 border-gray-700' 
              : 'bg-navy-700 hover:bg-navy-600 border-navy-600'
            } border`}
          >
            <Filter size={16} />
            <span className="text-sm font-mono">Filters</span>
          </button>
        </div>
        
        <div className="flex items-center gap-4">
          <button
            onClick={() => setView('monitor')}
            className={`px-3 py-1 rounded ${
              view === 'monitor'
                ? (highContrast ? 'bg-blue-600' : 'bg-navy-700 border-neon-cyan text-neon-cyan')
                : (highContrast ? 'bg-gray-800' : 'bg-navy-800')
            } border`}
          >
            Live Monitor
          </button>
          <button
            onClick={() => setView('history')}
            className={`px-3 py-1 rounded ${
              view === 'history'
                ? (highContrast ? 'bg-blue-600' : 'bg-navy-700 border-neon-cyan text-neon-cyan')
                : (highContrast ? 'bg-gray-800' : 'bg-navy-800')
            } border`}
          >
            History
          </button>
          <div className="flex items-center gap-2">
            <Calendar size={16} className="text-gray-500" />
            <span className="text-sm font-mono text-gray-400">
              {new Date().toLocaleDateString()}
            </span>
          </div>
        </div>
      </div>
      
      {view === 'monitor' ? (
        <ThreatMonitor />
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {threats.map((threat) => (
            <div 
              key={threat.id}
              className={`p-4 border rounded-lg ${
                highContrast 
                  ? 'bg-gray-900 border-gray-700' 
                  : 'bg-navy-800 border-navy-700'
              }`}
            >
              {/* Existing threat history view */}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Threats;