import { create } from 'zustand';
import { nanoid } from 'nanoid';
import { Threat, ThreatSeverity, MitigationStep } from '../types/threat';

interface ThreatState {
  threats: Threat[];
  activeThreatCount: number;
  addThreat: (threat: Omit<Threat, 'id' | 'timestamp'>) => void;
  updateThreatStatus: (id: string, status: Threat['status']) => void;
  addMitigationStep: (threatId: string, step: Omit<MitigationStep, 'id' | 'status'>) => void;
  updateMitigationStep: (threatId: string, stepId: string, status: MitigationStep['status'], error?: string) => void;
  updateThreatAnalysis: (threatId: string, analysis: Threat['analysis']) => void;
}

export const useThreatStore = create<ThreatState>((set, get) => ({
  threats: [],
  activeThreatCount: 0,

  addThreat: (threat) => {
    const newThreat: Threat = {
      ...threat,
      id: nanoid(),
      timestamp: new Date().toISOString(),
      status: 'active',
      mitigation: {
        steps: [],
      },
    };

    set((state) => ({
      threats: [newThreat, ...state.threats],
      activeThreatCount: state.activeThreatCount + 1,
    }));
  },

  updateThreatStatus: (id, status) => {
    set((state) => ({
      threats: state.threats.map((threat) =>
        threat.id === id ? { ...threat, status } : threat
      ),
      activeThreatCount: state.threats.filter(
        (t) => t.id !== id && t.status === 'active'
      ).length,
    }));
  },

  addMitigationStep: (threatId, step) => {
    const newStep: MitigationStep = {
      ...step,
      id: nanoid(),
      status: 'pending',
    };

    set((state) => ({
      threats: state.threats.map((threat) =>
        threat.id === threatId
          ? {
              ...threat,
              mitigation: {
                ...threat.mitigation,
                steps: [...(threat.mitigation?.steps || []), newStep],
              },
            }
          : threat
      ),
    }));
  },

  updateMitigationStep: (threatId, stepId, status, error) => {
    set((state) => ({
      threats: state.threats.map((threat) =>
        threat.id === threatId
          ? {
              ...threat,
              mitigation: {
                ...threat.mitigation,
                steps: threat.mitigation?.steps.map((step) =>
                  step.id === stepId
                    ? {
                        ...step,
                        status,
                        error,
                        ...(status === 'completed' ? { completedAt: new Date().toISOString() } : {}),
                        ...(status === 'in-progress' ? { startedAt: new Date().toISOString() } : {}),
                      }
                    : step
                ) || [],
              },
            }
          : threat
      ),
    }));
  },

  updateThreatAnalysis: (threatId, analysis) => {
    set((state) => ({
      threats: state.threats.map((threat) =>
        threat.id === threatId
          ? {
              ...threat,
              analysis: {
                ...threat.analysis,
                ...analysis,
              },
            }
          : threat
      ),
    }));
  },
}));