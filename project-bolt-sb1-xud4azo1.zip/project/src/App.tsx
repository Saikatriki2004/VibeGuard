import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import Devices from './pages/Devices';
import Threats from './pages/Threats';
import Updates from './pages/Updates';
import Settings from './pages/Settings';
import Login from './pages/Login';
import { ThemeProvider } from './context/ThemeContext';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // For demo purposes, we'll automatically authenticate
  React.useEffect(() => {
    // In a real app, this would check for a valid token
    const timer = setTimeout(() => setIsAuthenticated(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  if (!isAuthenticated) {
    return <Login onLogin={() => setIsAuthenticated(true)} />;
  }

  return (
    <ThemeProvider>
      <div className="crt scanline min-h-screen bg-navy-900 text-white">
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="devices" element={<Devices />} />
            <Route path="threats" element={<Threats />} />
            <Route path="updates" element={<Updates />} />
            <Route path="settings" element={<Settings />} />
          </Route>
        </Routes>
      </div>
    </ThemeProvider>
  );
}

export default App;