import React from 'react';
import { format } from 'date-fns';
import { Shield, AlertTriangle, AlertCircle, Clock, CheckCircle, XCircle } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { Threat, MitigationStep } from '../../types/threat';
import { useThreatStore } from '../../store/threatStore';

interface ThreatDetailsProps {
  threat: Threat;
}

export const ThreatDetails: React.FC<ThreatDetailsProps> = ({ threat }) => {
  const { highContrast } = useTheme();
  const { updateThreatStatus, addMitigationStep, updateMitigationStep } = useThreatStore();

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertCircle size={16} className={highContrast ? 'text-red-500' : 'text-neon-red'} />;
      case 'high':
        return <AlertTriangle size={16} className={highContrast ? 'text-orange-500' : 'text-terminal-amber'} />;
      case 'medium':
        return <AlertTriangle size={16} className={highContrast ? 'text-yellow-500' : 'text-terminal-amber'} />;
      case 'low':
      default:
        return <Shield size={16} className={highContrast ? 'text-blue-500' : 'text-neon-cyan'} />;
    }
  };

  const getStepStatusIcon = (status: MitigationStep['status']) => {
    switch (status) {
      case 'completed':
        return <CheckCircle size={16} className={highContrast ? 'text-green-500' : 'text-terminal-green'} />;
      case 'failed':
        return <XCircle size={16} className={highContrast ? 'text-red-500' : 'text-neon-red'} />;
      case 'in-progress':
        return <Clock size={16} className={highContrast ? 'text-blue-500' : 'text-neon-cyan'} />;
      default:
        return <Clock size={16} className="text-gray-500" />;
    }
  };

  const handleAddMitigationStep = () => {
    addMitigationStep(threat.id, {
      description: 'New mitigation step',
    });
  };

  const handleUpdateStep = (stepId: string, status: MitigationStep['status']) => {
    updateMitigationStep(threat.id, stepId, status);
  };

  return (
    <div className={`p-6 ${
      highContrast ? 'bg-gray-900 border-gray-700' : 'bg-navy-800 border-navy-700'
    } border rounded-lg space-y-6`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {getSeverityIcon(threat.severity)}
          <h2 className="text-xl font-mono font-bold">{threat.type}</h2>
        </div>
        <span className="text-sm text-gray-400 font-mono">
          {format(new Date(threat.timestamp), 'PPpp')}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h3 className="text-sm font-mono text-gray-400 mb-1">Description</h3>
          <p className="font-mono">{threat.description}</p>
        </div>
        <div>
          <h3 className="text-sm font-mono text-gray-400 mb-1">Source</h3>
          <p className="font-mono">{threat.source}</p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-mono">Mitigation Steps</h3>
          <button
            onClick={handleAddMitigationStep}
            className={`px-3 py-1 rounded ${
              highContrast
                ? 'bg-blue-600 hover:bg-blue-700'
                : 'bg-navy-700 border border-neon-cyan text-neon-cyan hover:bg-navy-600'
            }`}
          >
            Add Step
          </button>
        </div>

        <div className="space-y-2">
          {threat.mitigation?.steps.map((step) => (
            <div
              key={step.id}
              className={`p-3 border rounded ${
                highContrast ? 'bg-gray-800 border-gray-700' : 'bg-navy-700 border-navy-600'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getStepStatusIcon(step.status)}
                  <span className="font-mono">{step.description}</span>
                </div>
                <div className="flex gap-2">
                  {step.status !== 'completed' && (
                    <button
                      onClick={() => handleUpdateStep(step.id, 'completed')}
                      className={`px-2 py-1 rounded text-sm ${
                        highContrast
                          ? 'bg-green-600 hover:bg-green-700'
                          : 'bg-navy-600 text-terminal-green hover:bg-navy-500'
                      }`}
                    >
                      Complete
                    </button>
                  )}
                  {step.status === 'pending' && (
                    <button
                      onClick={() => handleUpdateStep(step.id, 'in-progress')}
                      className={`px-2 py-1 rounded text-sm ${
                        highContrast
                          ? 'bg-blue-600 hover:bg-blue-700'
                          : 'bg-navy-600 text-neon-cyan hover:bg-navy-500'
                      }`}
                    >
                      Start
                    </button>
                  )}
                </div>
              </div>
              {step.error && (
                <p className={`mt-2 text-sm ${
                  highContrast ? 'text-red-500' : 'text-neon-red'
                }`}>
                  Error: {step.error}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>

      {threat.analysis && (
        <div className="space-y-4">
          <h3 className="text-lg font-mono">Analysis</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {threat.analysis.rootCause && (
              <div>
                <h4 className="text-sm font-mono text-gray-400 mb-1">Root Cause</h4>
                <p className="font-mono">{threat.analysis.rootCause}</p>
              </div>
            )}
            {threat.analysis.impact && (
              <div>
                <h4 className="text-sm font-mono text-gray-400 mb-1">Impact Assessment</h4>
                <ul className="space-y-1 font-mono">
                  <li>Affected Devices: {threat.analysis.impact.affectedDevices}</li>
                  <li>Service Disruption: {threat.analysis.impact.serviceDisruption}</li>
                  <li>Data Compromise: {threat.analysis.impact.dataCompromise ? 'Yes' : 'No'}</li>
                  <li>Est. Recovery Time: {threat.analysis.impact.estimatedRecoveryTime} minutes</li>
                </ul>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default ThreatDetails;