import React, { useEffect } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { useThreatStore } from '../../store/threatStore';
import ThreatDetails from './ThreatDetails';

const ThreatMonitor: React.FC = () => {
  const { highContrast } = useTheme();
  const { threats, addThreat } = useThreatStore();

  // Simulate threat detection (for demo purposes)
  useEffect(() => {
    const interval = setInterval(() => {
      const random = Math.random();
      if (random < 0.1) { // 10% chance of new threat
        const severities = ['low', 'medium', 'high', 'critical'] as const;
        const types = ['PORT_SCAN', 'UNAUTH_ACCESS', 'MALFORMED_PACKET', 'FIRMWARE_TAMPER', 'BRUTE_FORCE'];
        const devices = ['sensor1', 'sensor2', 'gateway', 'controller1', 'unknown1'];
        
        addThreat({
          type: types[Math.floor(Math.random() * types.length)],
          severity: severities[Math.floor(Math.random() * severities.length)],
          device: devices[Math.floor(Math.random() * devices.length)],
          description: 'Suspicious activity detected',
          source: `192.168.1.${Math.floor(Math.random() * 255)}`,
          status: 'active',
        });
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [addThreat]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className={`text-xl font-pixel ${
          highContrast ? 'text-white' : 'text-neon-purple glow-purple'
        }`}>
          ACTIVE THREATS
        </h2>
        <div className={`px-3 py-1 rounded ${
          highContrast ? 'bg-gray-800' : 'bg-navy-700'
        }`}>
          <span className="font-mono">
            {threats.filter(t => t.status === 'active').length} Active
          </span>
        </div>
      </div>

      <div className="space-y-4">
        {threats
          .filter(threat => threat.status === 'active')
          .map(threat => (
            <ThreatDetails key={threat.id} threat={threat} />
          ))
        }
      </div>
    </div>
  );
};

export default ThreatMonitor;