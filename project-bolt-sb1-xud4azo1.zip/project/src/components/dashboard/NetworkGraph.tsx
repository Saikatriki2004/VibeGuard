import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { useTheme } from '../../context/ThemeContext';

interface Node {
  id: string;
  type: string;
  status: 'online' | 'offline' | 'warning' | 'threat';
}

interface Link {
  source: string;
  target: string;
  strength: number;
}

const NetworkGraph: React.FC = () => {
  const svgRef = useRef<SVGSVGElement>(null);
  const { highContrast } = useTheme();
  
  useEffect(() => {
    if (!svgRef.current) return;
    
    // Sample data
    const nodes: Node[] = [
      { id: 'gateway', type: 'gateway', status: 'online' },
      { id: 'sensor1', type: 'sensor', status: 'online' },
      { id: 'sensor2', type: 'sensor', status: 'online' },
      { id: 'sensor3', type: 'sensor', status: 'warning' },
      { id: 'sensor4', type: 'sensor', status: 'online' },
      { id: 'sensor5', type: 'sensor', status: 'online' },
      { id: 'sensor6', type: 'sensor', status: 'offline' },
      { id: 'controller1', type: 'controller', status: 'online' },
      { id: 'controller2', type: 'controller', status: 'online' },
      { id: 'unknown1', type: 'unknown', status: 'threat' },
    ];
    
    const links: Link[] = [
      { source: 'gateway', target: 'sensor1', strength: 0.9 },
      { source: 'gateway', target: 'sensor2', strength: 0.8 },
      { source: 'gateway', target: 'sensor3', strength: 0.5 },
      { source: 'gateway', target: 'sensor4', strength: 0.9 },
      { source: 'gateway', target: 'sensor5', strength: 0.7 },
      { source: 'gateway', target: 'controller1', strength: 0.9 },
      { source: 'gateway', target: 'controller2', strength: 0.9 },
      { source: 'sensor3', target: 'unknown1', strength: 0.3 },
      { source: 'controller1', target: 'sensor6', strength: 0.2 },
    ];
    
    const width = svgRef.current.clientWidth;
    const height = svgRef.current.clientHeight;
    
    // Clear previous graph
    d3.select(svgRef.current).selectAll('*').remove();
    
    // Create the simulation
    const simulation = d3.forceSimulation()
      .nodes(nodes as any)
      .force('link', d3.forceLink().id((d: any) => d.id).links(links))
      .force('charge', d3.forceManyBody().strength(-150))
      .force('center', d3.forceCenter(width / 2, height / 2));
    
    // Create the svg elements
    const svg = d3.select(svgRef.current);
    
    // Add links
    const link = svg.append('g')
      .selectAll('line')
      .data(links)
      .enter()
      .append('line')
      .attr('stroke', (d) => {
        if (highContrast) return '#888';
        
        if (d.target === 'unknown1' || d.source === 'unknown1') {
          return '#FF2D55';
        }
        return d.strength > 0.7 ? '#00FFFF' : '#666';
      })
      .attr('stroke-opacity', (d) => d.strength)
      .attr('stroke-width', (d) => Math.max(1, d.strength * 3));
    
    // Node status colors
    const getNodeColor = (status: string) => {
      if (highContrast) {
        switch(status) {
          case 'online': return '#22c55e';
          case 'warning': return '#f59e0b';
          case 'threat': return '#ef4444';
          case 'offline': return '#6b7280';
          default: return '#888';
        }
      }
      
      switch(status) {
        case 'online': return '#00FF66';
        case 'warning': return '#FFFF00';
        case 'threat': return '#FF2D55';
        case 'offline': return '#666';
        default: return '#888';
      }
    };
    
    // Add nodes
    const node = svg.append('g')
      .selectAll('circle')
      .data(nodes)
      .enter()
      .append('circle')
      .attr('r', (d) => d.type === 'gateway' ? 12 : 8)
      .attr('fill', (d) => getNodeColor(d.status))
      .attr('stroke', (d) => {
        if (highContrast) return '#fff';
        return d.type === 'gateway' ? '#FF00FF' : '#00FFFF';
      })
      .attr('stroke-width', (d) => d.type === 'gateway' ? 2 : 1)
      .call(d3.drag()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended) as any
      );
    
    // Add node labels
    const label = svg.append('g')
      .selectAll('text')
      .data(nodes)
      .enter()
      .append('text')
      .text((d) => d.id)
      .attr('font-size', '10px')
      .attr('font-family', 'monospace')
      .attr('dx', 12)
      .attr('dy', 4)
      .attr('fill', highContrast ? '#fff' : '#ccc');
    
    // Update positions on tick
    simulation.on('tick', () => {
      link
        .attr('x1', (d: any) => d.source.x)
        .attr('y1', (d: any) => d.source.y)
        .attr('x2', (d: any) => d.target.x)
        .attr('y2', (d: any) => d.target.y);
        
      node
        .attr('cx', (d: any) => d.x)
        .attr('cy', (d: any) => d.y);
        
      label
        .attr('x', (d: any) => d.x)
        .attr('y', (d: any) => d.y);
    });
    
    // Drag functions
    function dragstarted(event: any, d: any) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      d.fx = d.x;
      d.fy = d.y;
    }
    
    function dragged(event: any, d: any) {
      d.fx = event.x;
      d.fy = event.y;
    }
    
    function dragended(event: any, d: any) {
      if (!event.active) simulation.alphaTarget(0);
      d.fx = null;
      d.fy = null;
    }
    
    // Add a pulsing effect to threat nodes
    svg.selectAll('circle')
      .filter((d: any) => d.status === 'threat')
      .append('animate')
      .attr('attributeName', 'r')
      .attr('values', '8;10;8')
      .attr('dur', '1.5s')
      .attr('repeatCount', 'indefinite');
      
  }, [highContrast]);
  
  return (
    <div className="w-full h-[320px]">
      <svg ref={svgRef} width="100%" height="100%" />
    </div>
  );
};

export default NetworkGraph;