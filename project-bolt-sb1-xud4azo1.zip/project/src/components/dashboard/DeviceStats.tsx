import React from 'react';
import { HardDrive, Cpu, RefreshCw, Battery } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

const DeviceStats: React.FC = () => {
  const { highContrast } = useTheme();
  
  const deviceTypes = [
    {
      type: 'Sensors',
      count: 32,
      icon: HardDrive,
      color: highContrast ? 'text-blue-500' : 'text-neon-cyan',
      online: 30,
      offline: 2
    },
    {
      type: 'Controllers',
      count: 14,
      icon: Cpu,
      color: highContrast ? 'text-purple-500' : 'text-neon-purple',
      online: 12,
      offline: 2
    },
    {
      type: 'Gateways',
      count: 4,
      icon: RefreshCw,
      color: highContrast ? 'text-pink-500' : 'text-neon-pink',
      online: 4,
      offline: 0
    },
    {
      type: 'Battery Devices',
      count: 18,
      icon: Battery,
      color: highContrast ? 'text-green-500' : 'text-neon-green',
      online: 16,
      offline: 2
    }
  ];
  
  return (
    <div className={`${
      highContrast ? 'bg-gray-900 border-gray-700' : 'bg-navy-800 border-navy-700'
    } border rounded-lg p-4`}>
      <h2 className={`text-lg font-pixel mb-4 ${
        highContrast ? 'text-white' : 'text-neon-purple'
      }`}>
        DEVICE INVENTORY
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {deviceTypes.map((device, index) => (
          <div key={index} className={`${
            highContrast ? 'bg-gray-800 border-gray-700' : 'bg-navy-700 border-navy-600'
          } border rounded p-4`}>
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center gap-2">
                <device.icon size={18} className={device.color} />
                <span className="font-mono text-sm">{device.type}</span>
              </div>
              <span className="text-xl font-mono font-bold">{device.count}</span>
            </div>
            
            <div className="space-y-2">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className={highContrast ? 'text-gray-400' : 'text-gray-500'}>Online</span>
                  <span className={highContrast ? 'text-green-500' : 'text-terminal-green'}>{device.online}</span>
                </div>
                <div className="w-full bg-gray-900 rounded-full h-1.5">
                  <div 
                    className={highContrast ? 'bg-green-500' : 'bg-terminal-green'} 
                    style={{ width: `${(device.online / device.count) * 100}%` }}
                    className="h-1.5 rounded-full"
                  ></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className={highContrast ? 'text-gray-400' : 'text-gray-500'}>Offline</span>
                  <span className={highContrast ? 'text-gray-500' : 'text-gray-500'}>{device.offline}</span>
                </div>
                <div className="w-full bg-gray-900 rounded-full h-1.5">
                  <div 
                    className={highContrast ? 'bg-gray-600' : 'bg-gray-700'} 
                    style={{ width: `${(device.offline / device.count) * 100}%` }}
                    className="h-1.5 rounded-full"
                  ></div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DeviceStats;