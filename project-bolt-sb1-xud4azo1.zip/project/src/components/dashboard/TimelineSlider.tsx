import React, { useState } from 'react';
import { Calendar, Play, Pause } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

const TimelineSlider: React.FC = () => {
  const { highContrast } = useTheme();
  const [value, setValue] = useState(100);
  const [isPlaying, setIsPlaying] = useState(false);
  
  // Generate time labels for the timeline
  const timeLabels = [];
  const now = new Date();
  for (let i = 12; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 3600000);
    timeLabels.push(time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
  }
  
  // Event markers on the timeline
  const events = [
    { position: 15, type: 'low' },
    { position: 35, type: 'medium' },
    { position: 65, type: 'high' },
    { position: 90, type: 'critical' },
  ];
  
  const getEventMarkerColor = (type: string) => {
    if (highContrast) {
      switch (type) {
        case 'critical': return 'bg-red-500';
        case 'high': return 'bg-orange-500';
        case 'medium': return 'bg-yellow-500';
        case 'low': default: return 'bg-blue-500';
      }
    }
    
    switch (type) {
      case 'critical': return 'bg-neon-red';
      case 'high': return 'bg-terminal-amber';
      case 'medium': return 'bg-terminal-amber';
      case 'low': default: return 'bg-neon-cyan';
    }
  };
  
  const handleTogglePlay = () => {
    setIsPlaying(!isPlaying);
  };
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <button
            onClick={handleTogglePlay}
            className={`p-2 rounded ${
              highContrast 
                ? 'bg-gray-800 hover:bg-gray-700' 
                : 'bg-navy-700 hover:bg-navy-600'
            }`}
          >
            {isPlaying ? <Pause size={16} /> : <Play size={16} />}
          </button>
          
          <span className={`text-sm font-mono ${highContrast ? 'text-gray-300' : 'text-gray-400'}`}>
            {isPlaying ? 'LIVE VIEW' : 'TIMELINE PAUSED'}
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <Calendar size={16} className={highContrast ? 'text-gray-400' : 'text-gray-500'} />
          <span className={`text-sm font-mono ${highContrast ? 'text-gray-300' : 'text-gray-400'}`}>
            June 10, 2025
          </span>
        </div>
      </div>
      
      <div className="relative">
        {/* Event markers */}
        {events.map((event, index) => (
          <div
            key={index}
            className={`absolute w-1 h-3 ${getEventMarkerColor(event.type)}`}
            style={{ left: `${event.position}%`, top: '-8px' }}
            title={`${event.type} event`}
          ></div>
        ))}
        
        {/* Timeline slider */}
        <input
          type="range"
          min="0"
          max="100"
          value={value}
          onChange={(e) => setValue(parseInt(e.target.value))}
          className={`w-full h-1 appearance-none rounded cursor-pointer ${
            highContrast ? 'bg-gray-700' : 'bg-navy-700'
          }`}
          style={{
            backgroundImage: `linear-gradient(to right, ${
              highContrast ? '#3b82f6' : '#00FFFF'
            } 0%, ${
              highContrast ? '#3b82f6' : '#00FFFF'
            } ${value}%, ${
              highContrast ? '#374151' : '#232D4F'
            } ${value}%, ${
              highContrast ? '#374151' : '#232D4F'
            } 100%)`
          }}
        />
      </div>
      
      {/* Time labels */}
      <div className="flex justify-between text-xs font-mono text-gray-500">
        {timeLabels.map((label, index) => (
          <span key={index} className={index === timeLabels.length - 1 ? 'text-right' : ''}>
            {index % 3 === 0 ? label : ''}
          </span>
        ))}
      </div>
    </div>
  );
};

export default TimelineSlider;