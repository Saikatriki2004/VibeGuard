import React from 'react';
import { useTheme } from '../../context/ThemeContext';
import { Shield, AlertTriangle, AlertCircle } from 'lucide-react';

const ThreatFeed: React.FC = () => {
  const { highContrast } = useTheme();
  
  // Sample threat data
  const threats = [
    {
      id: 'T1001',
      type: 'PORT_SCAN',
      timestamp: '2025-06-10 14:23:15',
      severity: 'medium',
      device: 'sensor3',
      description: 'Suspicious port scanning activity detected'
    },
    {
      id: 'T1002',
      type: 'UNAUTH_ACCESS',
      timestamp: '2025-06-10 13:17:42',
      severity: 'high',
      device: 'controller2',
      description: 'Unauthorized access attempt with invalid credentials'
    },
    {
      id: 'T1003',
      type: 'MALFORMED_PACKET',
      timestamp: '2025-06-10 12:04:33',
      severity: 'low',
      device: 'gateway',
      description: 'Malformed packet detected and dropped'
    },
    {
      id: 'T1004',
      type: 'FIRMWARE_TAMPER',
      timestamp: '2025-06-10 09:58:11',
      severity: 'critical',
      device: 'unknown1',
      description: 'Potential firmware tampering detected'
    },
  ];
  
  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertCircle size={16} className={highContrast ? 'text-red-500' : 'text-neon-red'} />;
      case 'high':
        return <AlertTriangle size={16} className={highContrast ? 'text-orange-500' : 'text-terminal-amber'} />;
      case 'medium':
        return <AlertTriangle size={16} className={highContrast ? 'text-yellow-500' : 'text-terminal-amber'} />;
      case 'low':
      default:
        return <Shield size={16} className={highContrast ? 'text-blue-500' : 'text-neon-cyan'} />;
    }
  };
  
  const getSeverityClass = (severity: string) => {
    if (highContrast) {
      switch (severity) {
        case 'critical': return 'bg-red-950 border-red-800 text-red-500';
        case 'high': return 'bg-orange-950 border-orange-800 text-orange-500';
        case 'medium': return 'bg-yellow-950 border-yellow-800 text-yellow-500';
        case 'low': default: return 'bg-blue-950 border-blue-800 text-blue-500';
      }
    }
    
    switch (severity) {
      case 'critical': return 'bg-navy-700 border-neon-red text-neon-red border-glow-red';
      case 'high': return 'bg-navy-700 border-terminal-amber text-terminal-amber';
      case 'medium': return 'bg-navy-700 border-terminal-amber text-terminal-amber';
      case 'low': default: return 'bg-navy-700 border-neon-cyan text-neon-cyan';
    }
  };
  
  return (
    <div className="h-full overflow-y-auto pr-2 space-y-3">
      {threats.map((threat) => (
        <div 
          key={threat.id}
          className={`p-3 border rounded ${getSeverityClass(threat.severity)} ${
            highContrast ? '' : 'animate-flicker'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              {getSeverityIcon(threat.severity)}
              <span className="font-mono text-xs uppercase">{threat.type}</span>
            </div>
            <span className={`text-xs ${highContrast ? 'text-gray-400' : 'text-gray-500'}`}>
              {threat.timestamp}
            </span>
          </div>
          
          <p className="text-sm mb-1">
            {threat.description}
          </p>
          
          <div className="flex justify-between items-center mt-2 text-xs">
            <span className={highContrast ? 'text-gray-400' : 'text-gray-500'}>
              Device: <span className={highContrast ? 'text-white' : 'text-gray-300'}>
                {threat.device}
              </span>
            </span>
            
            <button className={`px-2 py-1 border rounded text-xs ${
              highContrast 
                ? 'border-gray-700 bg-gray-800 hover:bg-gray-700' 
                : 'border-navy-600 bg-navy-700 hover:bg-navy-600'
            }`}>
              Mitigate
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ThreatFeed;