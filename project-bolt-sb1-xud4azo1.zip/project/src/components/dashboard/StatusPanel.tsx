import React from 'react';
import { Shield, Server, Wifi, AlertTriangle } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

const StatusPanel: React.FC = () => {
  const { highContrast } = useTheme();
  
  const statusItems = [
    {
      icon: Shield,
      label: 'SECURITY',
      status: 'SECURE',
      statusClass: highContrast ? 'text-green-400' : 'text-terminal-green',
      details: 'No active threats detected'
    },
    {
      icon: Server,
      label: 'NODES',
      status: '48/50',
      statusClass: highContrast ? 'text-green-400' : 'text-terminal-green',
      details: '96% of devices online'
    },
    {
      icon: Wifi,
      label: 'NETWORK',
      status: 'STABLE',
      statusClass: highContrast ? 'text-green-400' : 'text-terminal-green',
      details: '128ms avg. latency'
    },
    {
      icon: AlertTriangle,
      label: 'ALERTS',
      status: '3',
      statusClass: highContrast ? 'text-amber-400' : 'text-terminal-amber',
      details: 'Requires attention'
    }
  ];
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {statusItems.map((item, index) => (
        <div 
          key={index} 
          className={`${
            highContrast 
              ? 'bg-gray-900 border-gray-700' 
              : 'bg-navy-800 border-navy-700'
          } border rounded-lg p-4 flex items-start gap-3`}
        >
          <div className={`p-2 rounded ${
            highContrast 
              ? 'bg-gray-800' 
              : 'bg-navy-700'
          }`}>
            <item.icon size={20} className={highContrast ? 'text-white' : 'text-neon-cyan'} />
          </div>
          
          <div>
            <p className="text-xs text-gray-500 font-mono">{item.label}</p>
            <p className={`text-lg font-mono font-bold ${item.statusClass}`}>
              {item.status}
            </p>
            <p className="text-xs text-gray-400 font-mono mt-1">{item.details}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default StatusPanel;