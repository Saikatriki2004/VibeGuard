import React from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';
import { useTheme } from '../../context/ThemeContext';

const Layout: React.FC = () => {
  const { highContrast } = useTheme();
  
  return (
    <div className={`flex h-screen ${highContrast ? 'bg-black' : 'bg-navy-900 grid-bg'}`}>
      <Sidebar />
      <div className="flex flex-col flex-grow overflow-hidden">
        <Header />
        <main className="flex-grow overflow-auto p-4">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;