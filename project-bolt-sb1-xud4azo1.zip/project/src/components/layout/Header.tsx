import React from 'react';
import { Bell, User, Moon } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

const Header: React.FC = () => {
  const { highContrast, toggleHighContrast } = useTheme();
  
  return (
    <header className={`h-16 ${highContrast ? 'bg-black border-b border-white' : 'bg-navy-800 border-b border-navy-700'} px-6 flex items-center justify-between`}>
      <div className="flex items-center">
        <div className={`text-sm font-pixel ${highContrast ? 'text-white' : 'text-neon-purple'}`}>
          SYSTEM STATUS: <span className={highContrast ? 'text-green-400' : 'text-terminal-green'}>SECURE</span>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <button 
          onClick={toggleHighContrast}
          className={`p-2 rounded ${highContrast ? 'bg-gray-700 text-white' : 'bg-navy-700 text-neon-cyan hover:text-neon-pink'} transition-colors`}
          title="Toggle high contrast mode"
        >
          <Moon size={18} />
        </button>
        
        <div className="relative">
          <button className={`p-2 rounded ${highContrast ? 'bg-gray-700 text-white' : 'bg-navy-700 text-neon-cyan hover:text-neon-pink'} transition-colors`}>
            <Bell size={18} />
          </button>
          <span className={`absolute -top-1 -right-1 w-4 h-4 rounded-full ${highContrast ? 'bg-red-600' : 'bg-neon-red animate-pulse'} text-xs flex items-center justify-center`}>
            3
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <div className={`w-8 h-8 rounded-full grid place-items-center ${highContrast ? 'bg-gray-700' : 'bg-navy-700 border border-neon-cyan'}`}>
            <User size={16} className={highContrast ? 'text-white' : 'text-neon-cyan'} />
          </div>
          <span className="text-sm font-mono">admin@vg</span>
        </div>
      </div>
    </header>
  );
};

export default Header;