import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Shield, HardDrive, RefreshCw, Settings } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

const Sidebar: React.FC = () => {
  const { highContrast } = useTheme();
  
  const NavItem = ({ to, icon: Icon, label }: { to: string, icon: React.ElementType, label: string }) => (
    <NavLink 
      to={to} 
      className={({ isActive }) => `
        flex items-center gap-3 px-4 py-3 my-1 rounded 
        transition-all duration-300 
        ${isActive 
          ? highContrast 
            ? 'bg-white text-black font-bold' 
            : 'bg-navy-700 text-neon-cyan border-glow-cyan border border-neon-cyan' 
          : highContrast 
            ? 'text-white hover:bg-gray-800' 
            : 'text-gray-300 hover:text-neon-pink hover:bg-navy-800'
        }
      `}
    >
      <Icon size={20} className={({ isActive }) => isActive ? (highContrast ? '' : 'text-neon-cyan') : ''} />
      <span className="font-mono">{label}</span>
    </NavLink>
  );

  return (
    <aside className={`w-56 h-full ${highContrast ? 'bg-black border-r border-white' : 'bg-navy-800 border-r border-navy-700'} flex flex-col`}>
      <div className="p-4">
        <div className="flex items-center gap-2 mb-10 mt-2">
          <div className="w-8 h-8 relative">
            <div className="absolute inset-0 bg-navy-900 border border-neon-pink rounded pixel-corners"></div>
            <Shield size={20} className="absolute inset-0 m-auto text-neon-pink" />
          </div>
          <h1 className={`font-pixel text-base ${highContrast ? 'text-white' : 'text-neon-pink glow-pink'}`}>VIBE<span className={highContrast ? 'text-white' : 'text-neon-cyan glow-cyan'}>GUARD</span></h1>
        </div>
        
        <nav className="flex flex-col">
          <NavItem to="/" icon={LayoutDashboard} label="Dashboard" />
          <NavItem to="/devices" icon={HardDrive} label="Devices" />
          <NavItem to="/threats" icon={Shield} label="Threats" />
          <NavItem to="/updates" icon={RefreshCw} label="Updates" />
          <NavItem to="/settings" icon={Settings} label="Settings" />
        </nav>
      </div>
      
      <div className="mt-auto p-4">
        <div className={`text-xs ${highContrast ? 'text-gray-400' : 'text-gray-500'}`}>
          <p>VibeGuard v1.0</p>
          <p>Running on: Bolt.new</p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;