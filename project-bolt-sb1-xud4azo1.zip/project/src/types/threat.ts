export type ThreatSeverity = 'low' | 'medium' | 'high' | 'critical';
export type ThreatStatus = 'active' | 'mitigating' | 'resolved' | 'investigating';

export interface Threat {
  id: string;
  type: string;
  timestamp: string;
  severity: ThreatSeverity;
  status: ThreatStatus;
  device: string;
  description: string;
  source: string;
  mitigation?: {
    steps: MitigationStep[];
    startedAt?: string;
    completedAt?: string;
    effectiveness?: number;
  };
  analysis?: {
    rootCause?: string;
    impact?: ThreatImpact;
    recommendations?: string[];
  };
}

export interface MitigationStep {
  id: string;
  description: string;
  status: 'pending' | 'in-progress' | 'completed' | 'failed';
  startedAt?: string;
  completedAt?: string;
  error?: string;
}

export interface ThreatImpact {
  affectedDevices: number;
  serviceDisruption: 'none' | 'minor' | 'major' | 'critical';
  dataCompromise: boolean;
  estimatedRecoveryTime: number; // in minutes
}